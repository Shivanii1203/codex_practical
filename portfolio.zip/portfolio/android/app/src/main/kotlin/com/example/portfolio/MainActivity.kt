package com.example.portfolio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
